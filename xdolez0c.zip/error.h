/*
 * @name Jáchym Doležal, xdolez0c
 * @faculty VUT FIT 2021/2022
 * @brief error.h
 * @date 19.4.2022
 */

void warning_msg(const char* fmt, ...);

void error_exit(const char* fmt, ...);