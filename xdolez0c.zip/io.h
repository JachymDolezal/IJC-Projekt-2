/*
 * @name Jáchym Doležal, xdolez0c
 * @faculty VUT FIT 2021/2022
 * @brief io.c .h file
 * @date 19.4.2022
 */

#include <stdio.h>
#include <stdlib.h>

int read_word(char* s, int max, FILE* f);